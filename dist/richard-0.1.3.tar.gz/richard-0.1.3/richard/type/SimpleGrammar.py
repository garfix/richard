from richard.type.SimpleGrammarRule import SimpleGrammarRule


SimpleGrammar = list[SimpleGrammarRule]