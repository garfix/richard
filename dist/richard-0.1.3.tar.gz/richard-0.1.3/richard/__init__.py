"""
Richard!

A Natural Language Understanding and Execution library for Python
"""

__version__ = "0.1.1"
__author__ = 'Patrick van Bergen'
