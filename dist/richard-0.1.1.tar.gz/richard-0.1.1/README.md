A Natural Language Understanding and Execution library for Python

## Requires

* Python 3.10 (or higher)

## Test

To run the unit tests:

    python3 -B -m unittest  tests/*.py

