SimpleGrammarRule = dict({'syn': str, 'sem': callable})
