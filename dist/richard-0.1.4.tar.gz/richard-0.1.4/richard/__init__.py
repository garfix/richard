"""
Richard!

A Natural Language Understanding and Execution library for Python
"""

__version__ = "0.1.4"
__author__ = 'Patrick van Bergen'
